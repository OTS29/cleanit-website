import type { MetadataRoute } from "next";
import { SITE } from "./lib/config";

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ["", "/services", "/pricing", "/book", "/gallery", "/about", "/faq", "/contact", "/privacy", "/terms"];
  return pages.map((p) => ({ url: `${SITE.url}${p}`, lastModified: new Date() }));
}
