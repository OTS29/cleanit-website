import { SITE, whatsappLink } from "../lib/config";

export const metadata = { title: "FAQ" };

export default function FAQPage() {
  const faqs: { q: string; a: string }[] = [
    {
      q: "Do you bring your own cleaning supplies?",
      a: "By default we use your own products and equipment. If you would rather we bring everything, choose \"We provide\" in the price calculator (extra charge) or tell us when you book.",
    },
    {
      q: "Do I need to be home during the cleaning?",
      a: "No. As long as we can access the property, you do not need to be present. Many customers prefer to return once the cleaning is complete.",
    },
    {
      q: "How do I pay for the service?",
      a: "We accept bank transfer or cash. Payment details are sent once your booking is confirmed.",
    },
    {
      q: "Do you offer Airbnb cleaning?",
      a: "Yes. We offer turnaround cleaning including a linen change and a guest-ready finish. Tell us your check-out and check-in times when you book.",
    },
    {
      q: "Do you offer end-of-tenancy cleaning?",
      a: "Yes. We clean to the standard landlords and agents normally expect. Tell us about any specific checklist you have been given.",
    },
    {
      q: "Can I book on WhatsApp?",
      a: "Yes. WhatsApp is a quick way to book. You can send photos, ask questions and get a fast reply.",
    },
    {
      q: "Which areas do you cover?",
      a: `We cover ${SITE.area}. Other London areas on request.`,
    },
  ];
  if (SITE.recleanPromise) {
    faqs.push({ q: "What if something is missed?", a: "Tell us within 24 hours and we will come back and put it right at no extra charge." });
  }
  if (SITE.insured) {
    faqs.push({ q: "Are you insured?", a: "Yes. We carry public liability insurance. Ask us if you need a copy of the certificate." });
  }
  if (SITE.dbsChecked) {
    faqs.push({ q: "Are your cleaners DBS-checked?", a: "Yes. Every cleaner has a DBS check." });
  }

  return (
    <div className="min-h-screen bg-white px-6 py-12">
      <h1 className="text-3xl font-bold text-slate-900 text-center mb-4">Frequently Asked Questions</h1>

      <p className="text-center text-slate-600 max-w-2xl mx-auto mb-10">
        Everything you need to know about {SITE.brand}&apos;s cleaning services.
      </p>

      <div className="max-w-4xl mx-auto space-y-6">
        {faqs.map((item) => (
          <div key={item.q} className="border border-slate-200 rounded-lg p-6 shadow-sm hover:shadow-md transition">
            <h3 className="text-lg font-semibold text-slate-900 mb-2">{item.q}</h3>
            <p className="text-slate-700">{item.a}</p>
          </div>
        ))}
      </div>

      <div className="text-center mt-12">
        <a href={whatsappLink("Hi, I have a question about your cleaning service.")} className="inline-block bg-slate-900 text-white px-6 py-3 rounded-md font-semibold text-sm hover:bg-slate-700 shadow-md">
          Ask on WhatsApp
        </a>
      </div>
    </div>
  );
}
