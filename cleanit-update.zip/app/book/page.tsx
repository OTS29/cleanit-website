"use client";

import { useState } from "react";
import Link from "next/link";
import { SITE, whatsappLink } from "../lib/config";
import { sendToFormspree } from "../lib/submit";

const field = "w-full border border-slate-300 rounded-md px-4 py-3 bg-white";

export default function BookingPage() {
  const [state, setState] = useState<"idle" | "sending" | "done">("idle");
  const [error, setError] = useState("");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    setState("sending");
    const r = await sendToFormspree(e.currentTarget);
    if (r.ok) setState("done");
    else { setError(r.error || "Something went wrong."); setState("idle"); }
  };

  if (state === "done") {
    return (
      <div className="min-h-screen bg-white px-6 py-12">
        <div className="text-center max-w-xl mx-auto bg-slate-100 p-8 rounded-lg shadow">
          <h1 className="text-2xl font-bold mb-4">Booking request received</h1>
          <p className="text-slate-700 mb-4">
            Thank you. This is a request, not a confirmed booking yet. We will check availability and contact you shortly by phone, WhatsApp or email to confirm the date and price.
          </p>
          <Link href="/" className="inline-block bg-slate-900 text-white px-6 py-3 rounded-md font-semibold hover:bg-slate-700">Back to Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white px-4 sm:px-6 py-12">
      <h1 className="text-3xl font-bold text-center mb-2">Request a Booking</h1>
      <p className="text-center text-slate-600 max-w-xl mx-auto mb-8">
        Tell us what you need and we will confirm availability and price. Want an instant estimate first? <Link href="/pricing" className="underline text-green-700">Use the price calculator</Link>.
      </p>

      <form onSubmit={onSubmit} className="max-w-xl mx-auto bg-slate-100 p-6 rounded-lg shadow space-y-4">
        <input type="hidden" name="_subject" value={`New booking request - ${SITE.brand}`} />
        {/* Hidden trap for spam robots. Real visitors never see or fill this in. */}
        <input type="text" name="_gotcha" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />

        <input type="text" name="name" placeholder="Your name" required autoComplete="name" className={field} />
        <input type="email" name="email" placeholder="Your email" required autoComplete="email" className={field} />
        <input type="tel" name="phone" placeholder="Phone number" required autoComplete="tel" className={field} />
        <input type="text" name="address" placeholder="Address" required autoComplete="street-address" className={field} />
        <input type="text" name="postcode" placeholder="Postcode" required autoComplete="postal-code" className={field} />

        <select name="service" required defaultValue="" className={field}>
          <option value="" disabled>Select service</option>
          <option value="Regular Cleaning">Regular Cleaning</option>
          <option value="Deep Cleaning">Deep Cleaning</option>
          <option value="End of Tenancy">End of Tenancy</option>
          <option value="Airbnb Cleaning">Airbnb Cleaning</option>
          <option value="Office Cleaning">Office Cleaning</option>
          <option value="Other">Other</option>
        </select>

        <div className="grid grid-cols-2 gap-4">
          <label className="text-sm text-slate-600">Preferred date
            <input type="date" name="date" required className={`${field} mt-1`} />
          </label>
          <label className="text-sm text-slate-600">Preferred time
            <input type="time" name="time" required className={`${field} mt-1`} />
          </label>
        </div>

        <textarea name="notes" placeholder="Property size, access details or anything else we should know (optional)" rows={4} className={field} />

        <label className="flex gap-3 text-sm text-slate-700 items-start">
          <input type="checkbox" name="consent" value="yes" required className="mt-1" />
          <span>I agree that {SITE.brand} may use these details to reply to my request, as described in the <Link href="/privacy" className="underline">privacy policy</Link>.</span>
        </label>

        {error && <p className="text-red-600 text-sm">{error}</p>}

        <button type="submit" disabled={state === "sending"} className="w-full bg-slate-900 text-white py-3 rounded-md font-semibold hover:bg-slate-700 disabled:opacity-60">
          {state === "sending" ? "Sending…" : "Send booking request"}
        </button>

        <a href={whatsappLink("Hi, I would like to book a clean.")} className="block text-center bg-green-600 text-white py-3 rounded-md font-semibold hover:bg-green-500">
          Or book on WhatsApp
        </a>
      </form>
    </div>
  );
}
