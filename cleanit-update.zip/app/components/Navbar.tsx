"use client";
import Link from "next/link";
import { useState } from "react";
import { SITE } from "../lib/config";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/services", label: "Services" },
  { href: "/pricing", label: "Pricing" },
  { href: "/gallery", label: "Gallery" },
  { href: "/about", label: "About" },
  { href: "/faq", label: "FAQ" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <nav className="w-full bg-white shadow-md fixed top-0 left-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        <Link href="/" className="text-green-500 text-2xl font-bold" onClick={() => setOpen(false)}>
          {SITE.brand}
        </Link>

        <div className="hidden md:flex gap-6 text-sm font-semibold text-slate-700">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="hover:text-green-600">{l.label}</Link>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <Link href="/book" className="bg-green-500 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-green-600">
            Book Now
          </Link>
          <button
            type="button"
            aria-label="Menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="md:hidden border border-slate-300 rounded-md px-3 py-2 text-slate-700"
          >
            {open ? "✕" : "☰"}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pb-4">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="block py-3 text-sm font-semibold text-slate-700 border-b border-slate-100">
              {l.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}
