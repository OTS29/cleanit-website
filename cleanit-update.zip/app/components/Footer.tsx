import Link from "next/link";
import { SITE, businessName, whatsappLink } from "../lib/config";

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-12 mt-20">
      <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-10">
        <div>
          <h3 className="text-xl font-bold">{SITE.brand}</h3>
          <p className="text-sm text-slate-300 mt-3">
            Domestic, Airbnb, office and deep cleaning in {SITE.areaShort}.
          </p>
        </div>

        <div>
          <h4 className="text-lg font-semibold mb-3">Quick Links</h4>
          <ul className="space-y-2 text-sm text-slate-300">
            <li><Link href="/" className="hover:text-white">Home</Link></li>
            <li><Link href="/services" className="hover:text-white">Services</Link></li>
            <li><Link href="/pricing" className="hover:text-white">Pricing</Link></li>
            <li><Link href="/gallery" className="hover:text-white">Gallery</Link></li>
            <li><Link href="/faq" className="hover:text-white">FAQ</Link></li>
            <li><Link href="/contact" className="hover:text-white">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-lg font-semibold mb-3">Contact Us</h4>
          <p className="text-sm text-slate-300">Phone: <a href={`tel:+${SITE.phoneIntl}`} className="hover:text-white">{SITE.phoneDisplay}</a></p>
          <p className="text-sm text-slate-300">Email: <a href={`mailto:${SITE.email}`} className="hover:text-white">{SITE.email}</a></p>
          <a href={whatsappLink()} className="inline-block mt-4 bg-white text-slate-900 px-4 py-2 rounded-md text-sm font-semibold hover:bg-slate-200">
            Chat on WhatsApp
          </a>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 mt-10 text-center text-xs text-slate-400 space-y-2">
        <p>
          <Link href="/privacy" className="hover:text-white underline">Privacy</Link>
          {" · "}
          <Link href="/terms" className="hover:text-white underline">Terms</Link>
        </p>
        {(SITE.legalName || SITE.companyNumber) && (
          <p>
            {businessName()}
            {SITE.companyNumber ? ` · Company number ${SITE.companyNumber}` : ""}
            {SITE.registeredAddress ? ` · Registered office: ${SITE.registeredAddress}` : ""}
          </p>
        )}
        <p>© {new Date().getFullYear()} {businessName()}. All rights reserved.</p>
      </div>
    </footer>
  );
}
