import Link from "next/link";
import { SITE, whatsappLink } from "../lib/config";

export const metadata = { title: "About" };

export default function AboutPage() {
  const cards: { title: string; text: string }[] = [
    { title: "✔ Careful and reliable", text: "We agree what is included before we start, arrive when we say we will, and keep you updated." },
    { title: "✔ Clear pricing", text: "Use the instant price calculator to see an estimate. Anything extra is agreed with you first." },
    { title: "✔ Local", text: `We serve ${SITE.area}. Other London areas on request.` },
  ];
  if (SITE.recleanPromise) cards.push({ title: "✔ We put it right", text: "If something was missed, tell us within 24 hours and we will come back and put it right." });
  if (SITE.insured) cards.push({ title: "✔ Insured", text: "We carry public liability insurance." });
  if (SITE.dbsChecked) cards.push({ title: "✔ DBS-checked", text: "Every cleaner has a DBS check." });

  return (
    <div className="min-h-screen bg-white px-6 py-12">
      <h1 className="text-3xl font-bold text-slate-900 text-center mb-4">About {SITE.brand}</h1>

      <p className="text-center text-slate-600 max-w-2xl mx-auto mb-10">
        {SITE.brand} is a London cleaning business for homes, landlords, Airbnb hosts and small businesses in {SITE.areaShort}.
        We focus on reliable, careful work and honest prices.
      </p>

      <section className="max-w-4xl mx-auto mb-16">
        <h2 className="text-2xl font-semibold text-slate-900 mb-4">Our aim</h2>
        <p className="text-slate-700 leading-relaxed">
          A clean space makes life easier. Our aim is simple: do the job properly, tell you the price up front, and make booking easy, whether you prefer a form, a phone call or WhatsApp.
        </p>
      </section>

      <section className="max-w-4xl mx-auto mb-16">
        <h2 className="text-2xl font-semibold text-slate-900 mb-4">Why choose {SITE.brand}?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {cards.map((c) => (
            <div key={c.title} className="border border-slate-200 p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold text-slate-900 mb-2">{c.title}</h3>
              <p className="text-slate-700">{c.text}</p>
            </div>
          ))}
        </div>
      </section>

      <div className="text-center mt-12 flex flex-wrap gap-3 justify-center">
        <Link href="/book" className="inline-block bg-green-600 text-white px-6 py-3 rounded-md font-semibold text-sm hover:bg-green-500 shadow-md">Request a booking</Link>
        <a href={whatsappLink("Hi, I would like to book a clean.")} className="inline-block bg-slate-900 text-white px-6 py-3 rounded-md font-semibold text-sm hover:bg-slate-700 shadow-md">Book on WhatsApp</a>
      </div>
    </div>
  );
}
