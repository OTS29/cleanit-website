import { SITE, businessName } from "../lib/config";

export const metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-white px-6 py-12">
      <article className="max-w-3xl mx-auto text-slate-700 leading-relaxed space-y-5">
        <h1 className="text-3xl font-bold text-slate-900">Terms of Service</h1>
        <p className="text-sm text-slate-500">Last updated: October 2026</p>
        <p>
          These terms apply when you book cleaning with {businessName()}, trading as {SITE.brand}. They do not affect your legal rights as a consumer.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">1. Bookings and prices</h2>
        <p>
          A form or message is a request, not a confirmed booking. A booking is confirmed when we confirm the date, time and price with you. Prices shown by the online calculator are estimates; we will confirm the final price before the work starts, and agree any extras with you first.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">2. Payment</h2>
        <p>
          Payment is due on completion unless we agree otherwise in writing. We accept bank transfer or cash. Payment details are sent when your booking is confirmed.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">3. Changes and cancellations</h2>
        <p>
          Please give at least 24 hours&apos; notice to change or cancel. If you cancel with less notice, or we cannot get in at the agreed time, we may charge up to half of the estimated price. If you booked online or by message, you also have 14 days to cancel under the Consumer Contracts Regulations. If you ask us to start within that period, you will pay for the work done up to the point you cancel.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">4. Access and supplies</h2>
        <p>
          Please make sure we can get into the property and that water and electricity are available. Unless you chose &quot;We provide&quot;, we use your cleaning products and equipment. Tell us about fragile items, pets, allergies or surfaces that need special care.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">5. Our service and complaints</h2>
        <p>
          We will carry out the work with reasonable care and skill.
          {SITE.recleanPromise ? " If something was missed, tell us within 24 hours and we will come back and put it right at no extra charge." : " If you are unhappy, tell us within 24 hours so we can try to put it right."}
          {" "}Please report any damage within 24 hours so we can look into it.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">6. Liability</h2>
        <p>
          Nothing in these terms limits liability that cannot be limited by law, including for death or personal injury caused by negligence, or for fraud.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">7. Contact</h2>
        <p>
          {businessName()}{SITE.companyNumber ? `, company number ${SITE.companyNumber}` : ""}{SITE.registeredAddress ? `, ${SITE.registeredAddress}` : ""}. Email <a className="underline" href={`mailto:${SITE.email}`}>{SITE.email}</a> or phone {SITE.phoneDisplay}.
        </p>
      </article>
    </div>
  );
}
