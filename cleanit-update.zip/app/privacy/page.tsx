import { SITE, businessName } from "../lib/config";

export const metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-white px-6 py-12">
      <article className="max-w-3xl mx-auto text-slate-700 leading-relaxed space-y-5">
        <h1 className="text-3xl font-bold text-slate-900">Privacy Policy</h1>
        <p className="text-sm text-slate-500">Last updated: October 2026</p>

        <h2 className="text-xl font-semibold text-slate-900">Who we are</h2>
        <p>
          This website is run by {businessName()}{SITE.companyNumber ? ` (company number ${SITE.companyNumber})` : ""}, trading as {SITE.brand}.
          {SITE.registeredAddress ? ` Registered office: ${SITE.registeredAddress}.` : ""} You can contact us at <a className="underline" href={`mailto:${SITE.email}`}>{SITE.email}</a> or on {SITE.phoneDisplay}.
          We are responsible for your personal information (the &quot;data controller&quot;).
        </p>

        <h2 className="text-xl font-semibold text-slate-900">What we collect</h2>
        <p>
          When you send a booking request, contact form or WhatsApp message we collect your name, email address, phone number, address and postcode, details of the service you want, and anything you write to us.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">Why we use it</h2>
        <ul className="list-disc pl-6 space-y-1">
          <li>To reply to your enquiry, give you a quote and arrange the cleaning you ask for (needed to take steps at your request before a contract, and to carry out the contract).</li>
          <li>To keep records of our work, invoices and payments (a legal obligation).</li>
          <li>To handle complaints and protect our legitimate business interests.</li>
        </ul>
        <p>We do not sell your data and we do not use it for advertising.</p>

        <h2 className="text-xl font-semibold text-slate-900">Who we share it with</h2>
        <p>
          Only the services we need to run the business: Formspree (receives the forms you submit and emails them to us), WhatsApp (if you message us there), our website host (Vercel), and our email and bank providers. Some of these may process data outside the UK, with safeguards required by UK law.
          We may share your name, address and booking details with a cleaner who is carrying out your booking.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">How long we keep it</h2>
        <p>
          Enquiries that do not lead to a booking: up to 12 months. Records of work, invoices and payments: 6 years, as the law requires for accounts.
        </p>

        <h2 className="text-xl font-semibold text-slate-900">Cookies</h2>
        <p>This website does not use advertising or tracking cookies.</p>

        <h2 className="text-xl font-semibold text-slate-900">Your rights</h2>
        <p>
          You can ask us to see, correct or delete your information, restrict or object to how we use it, or move it to another provider. Email us and we will reply within one month.
          If you are unhappy with how we handle your data, you can complain to the Information Commissioner&apos;s Office at <a className="underline" href="https://ico.org.uk">ico.org.uk</a> or on 0303 123 1113.
        </p>
      </article>
    </div>
  );
}
