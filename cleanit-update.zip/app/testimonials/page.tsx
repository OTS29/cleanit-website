import Link from "next/link";
import { SITE } from "../lib/config";

export const metadata = { title: "Reviews", robots: { index: false } };

// There are no reviews on this site yet. Add real ones here once customers have given them.
export default function ReviewsPage() {
  return (
    <div className="min-h-screen bg-white px-6 py-16 text-center">
      <h1 className="text-3xl font-bold text-slate-900 mb-4">Reviews</h1>
      <p className="text-slate-600 max-w-xl mx-auto mb-8">
        {SITE.brand} is new, so we do not have customer reviews to show yet. We would rather show none than show anything that is not real.
      </p>
      <Link href="/book" className="inline-block bg-green-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-green-500">Request a booking</Link>
    </div>
  );
}
