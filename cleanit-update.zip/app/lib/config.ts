// ONE place for your business details. Change a value here and it updates the whole website.

export const SITE = {
  brand: "Cleanit",
  // The address of the live website (used for search engines). Change it when you get your own domain.
  url: "https://cleanit-website.vercel.app",

  phoneDisplay: "07735 541705",
  phoneIntl: "447735541705", // no + and no spaces
  email: "bookings@londonsparklecleaning.co.uk", // CHANGE THIS to an email address you really use

  // Where booking and contact forms are sent (your Formspree form).
  formspree: "https://formspree.io/f/xbgjzzyl",

  area: "Lewisham, Catford, Greenwich, Deptford, Blackheath, Bromley and surrounding South East London",
  areaShort: "Lewisham and South East London",

  // Fill these in once the company is registered. They appear in the footer and the legal pages.
  legalName: "", // e.g. "Your Company Ltd"
  companyNumber: "", // e.g. "12345678"
  registeredAddress: "", // the registered office address

  // Turn these on ONLY when they are true. They control the badges and answers on the site.
  insured: false, // public liability insurance in place
  dbsChecked: false, // every cleaner has a DBS check
  recleanPromise: true, // "tell us within 24 hours and we will come back and put it right"
};

export const whatsappLink = (text?: string) =>
  `https://wa.me/${SITE.phoneIntl}${text ? `?text=${encodeURIComponent(text)}` : ""}`;

export const businessName = () => SITE.legalName || SITE.brand;
