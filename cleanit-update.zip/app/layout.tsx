import "./globals.css";
import type { Metadata, Viewport } from "next";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import { SITE } from "./lib/config";

const title = `${SITE.brand} | Cleaning Services in ${SITE.areaShort}`;
const description = `Domestic, Airbnb, office and deep cleaning in ${SITE.areaShort}. Get an instant price estimate and book online or on WhatsApp.`;

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: title, template: `%s | ${SITE.brand}` },
  description,
  openGraph: { title, description, url: SITE.url, siteName: SITE.brand, type: "website", locale: "en_GB" },
  twitter: { card: "summary", title, description },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = { width: "device-width", initialScale: 1 };

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "CleaningService",
  name: SITE.brand,
  url: SITE.url,
  telephone: `+${SITE.phoneIntl}`,
  email: SITE.email,
  description,
  areaServed: SITE.area.split(/,| and /).map((s) => s.trim()).filter(Boolean),
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB">
      <body className="bg-slate-50">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
        <Navbar />
        <main className="pt-20">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
