# Cleanit update

## 1. Install
In Terminal, inside your primecleanuk folder:

    unzip -o ~/Desktop/cleanit-update.zip
    rm -rf app/admin app/analytics app/dashboard app/login app/reset-password app/api
    rm -f public/image1.png public/image2.png public/image3.png public/gallery2.png public/gallery3.png
    git add . && git commit -m "Cleanit update"
    git push

(Run `git push` on its own line. Do not type anything after it.)

## 2. Edit ONE file: app/lib/config.ts
- email: put an email address you really use (it currently shows bookings@londonsparklecleaning.co.uk).
- legalName, companyNumber, registeredAddress: fill in when the company is registered.
- insured: change to true ONLY when you have public liability insurance.
- dbsChecked: change to true ONLY when every cleaner has a DBS check.
- recleanPromise: true means the site promises "tell us within 24 hours and we will come back". Set false if you do not want to promise that.

## 3. In Formspree
Check forms are delivered to an email you read (formspree.io, your form "xbgjzzyl").

## What changed
- One brand name: Cleanit.
- Removed: invented customer reviews, unproven "DBS-checked", "fully insured" and "100% guarantee" claims, the fake admin/cleaner login, the open email route, and browser-only booking storage.
- Booking and contact forms now stay on the page, show a proper thank-you, include a consent tick and spam trap, and email you through Formspree.
- New pages: Privacy and Terms (templates; have them checked before relying on them). robots.txt and sitemap.
- Mobile menu, search title and description, local business data for Google, faster images.
- Home page shows "from" prices. The price calculator is unchanged.
