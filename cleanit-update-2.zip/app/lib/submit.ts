import { SITE } from "./config";

// Sends form data to Formspree without leaving the page, so the visitor always sees a proper thank-you message.
export async function sendFormData(data: FormData): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(SITE.formspree, {
      method: "POST",
      headers: { Accept: "application/json" },
      body: data,
    });
    if (res.ok) return { ok: true };
    return { ok: false, error: "Sorry, that did not send. Please try again or message us on WhatsApp." };
  } catch {
    return { ok: false, error: "No connection. Please check your internet and try again, or message us on WhatsApp." };
  }
}

export const sendToFormspree = (form: HTMLFormElement) => sendFormData(new FormData(form));
