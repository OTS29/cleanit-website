"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { SITE, whatsappLink } from "../lib/config";
import { sendFormData } from "../lib/submit";

type ServiceType =
  | "Domestic Cleaning"
  | "Airbnb Cleaning"
  | "Office Cleaning"
  | "Hotel Cleaning"
  | "Commercial Cleaning"
  | "Deep Cleaning"
  | "";

type PropertyCondition = "Existing" | "New Build" | "Renovated";
type SuppliesOption = "Customer Provides" | "We Provide";

type PricingForm = {
  service: ServiceType;
  propertyType: string;
  condition: PropertyCondition;
  supplies: SuppliesOption;
  hours: number;
  rooms: number;
  bathrooms: number;
  toilets: number;
  drainage: boolean;
  extras: string[];
  notes: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  postcode: string;
  bookingDate: string;
  bookingTime: string;
};

const extraOptions = [
  { name: "Inside Oven", price: 15 },
  { name: "Inside Fridge", price: 10 },
  { name: "Windows (Internal)", price: 20 },
  { name: "Balcony Cleaning", price: 15 },
  { name: "Carpet Vacuum", price: 10 },
];

const serviceRates: Record<ServiceType, number> = {
  "Domestic Cleaning": 20,
  "Airbnb Cleaning": 45,
  "Office Cleaning": 22,
  "Hotel Cleaning": 25,
  "Commercial Cleaning": 28,
  "Deep Cleaning": 160,
  "": 0,
};

export default function PricingPage() {
  const [form, setForm] = useState<PricingForm>({
    service: "",
    propertyType: "",
    condition: "Existing",
    supplies: "Customer Provides",
    hours: 1,
    rooms: 0,
    bathrooms: 0,
    toilets: 0,
    drainage: false,
    extras: [],
    notes: "",
    name: "",
    phone: "",
    email: "",
    address: "",
    postcode: "",
    bookingDate: "",
    bookingTime: "",
  });

  const inputStyle =
    "w-full mt-2 p-3 border border-slate-400 rounded-md bg-white text-slate-900 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-green-500";

  // ⭐ Auto-set minimum hours based on rooms, bathrooms, toilets, condition, drainage
  const calculateMinimumHours = () => {
    let hours = 1;

    // Rooms
    if (form.rooms <= 1) hours = 1;
    else if (form.rooms <= 2) hours = 2;
    else if (form.rooms <= 3) hours = 3;
    else if (form.rooms <= 4) hours = 3.5;
    else if (form.rooms <= 6) hours = 4;
    else hours = 5;

    // Bathrooms
    hours += form.bathrooms * 0.5;

    // Toilets
    hours += form.toilets * 0.25;

    // Property condition
    if (form.condition === "New Build") hours += 1;
    if (form.condition === "Renovated") hours += 2;

    // Drainage cleaning
    if (form.drainage) hours += 1;

    return hours;
  };

  useEffect(() => {
    const minHours = calculateMinimumHours();
    if (form.hours < minHours) {
      setForm((prev) => ({ ...prev, hours: minHours }));
    }
  }, [form.rooms, form.bathrooms, form.toilets, form.condition, form.drainage]);

  const toggleExtra = (extra: string) => {
    setForm((prev) => ({
      ...prev,
      extras: prev.extras.includes(extra)
        ? prev.extras.filter((e) => e !== extra)
        : [...prev.extras, extra],
    }));
  };

  // ⭐ Corrected pricing logic
  const calculateTotal = () => {
    if (
      form.service === "Hotel Cleaning" ||
      form.service === "Commercial Cleaning" ||
      form.service === "Office Cleaning"
    ) {
      return "Contact us for a quote";
    }

    let base = form.service ? serviceRates[form.service] * form.hours : 0;

    const rooms = Math.min(form.rooms, 10);
    const bathrooms = Math.min(form.bathrooms, 5);
    const toilets = Math.min(form.toilets, 5);

    base += rooms * 5;
    base += bathrooms * 10;
    base += toilets * 5;

    // Drainage cleaning
    if (form.drainage) base += 20;

    // Supplies
    if (form.supplies === "We Provide") base += 15;

    // Extras
    form.extras.forEach((extra) => {
      const item = extraOptions.find((x) => x.name === extra);
      if (item) base += item.price;
    });

    return base;
  };

  const totalPrice = calculateTotal();

  const whatsappMessage = () => {
    const msg = `
📄 Cleaning Booking Request

👤 Name: ${form.name}
📞 Phone: ${form.phone}
📧 Email: ${form.email}

🏠 Address: ${form.address}
🔢 Postcode: ${form.postcode}
🏢 Property Type: ${form.propertyType}
🏗 Condition: ${form.condition}
🧴 Supplies: ${form.supplies}

🧹 Service Type: ${form.service}
⏱ Hours Needed: ${form.hours}

🛏 Rooms: ${form.rooms}
🚿 Bathrooms: ${form.bathrooms}
🚽 Toilets: ${form.toilets}
🕳 Drainage Cleaning: ${form.drainage ? "Yes" : "No"}

✨ Extras: ${form.extras.join(", ") || "None"}

📅 Booking Date: ${form.bookingDate}
⏰ Booking Time: ${form.bookingTime}

📝 Notes: ${form.notes || "None"}

💷 Total Estimated Price: £${totalPrice}

Please confirm availability.
    `;

    return whatsappLink(msg.trim());
  };

  const [consent, setConsent] = useState(false);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");

  const sendRequest = async () => {
    setErr("");
    if (!form.service) return setErr("Please choose a service.");
    if (!form.name.trim() || !form.phone.trim() || !form.email.trim() || !form.postcode.trim()) {
      return setErr("Please fill in your name, phone, email and postcode.");
    }
    if (!consent) return setErr("Please tick the box to agree to the privacy policy.");
    const fd = new FormData();
    fd.append("_subject", `Price request - ${SITE.brand}`);
    fd.append("name", form.name);
    fd.append("phone", form.phone);
    fd.append("email", form.email);
    fd.append("address", form.address);
    fd.append("postcode", form.postcode);
    fd.append("service", form.service);
    fd.append("property_type", form.propertyType);
    fd.append("condition", form.condition);
    fd.append("supplies", form.supplies);
    fd.append("hours", String(form.hours));
    fd.append("rooms", String(form.rooms));
    fd.append("bathrooms", String(form.bathrooms));
    fd.append("toilets", String(form.toilets));
    fd.append("drainage", form.drainage ? "Yes" : "No");
    fd.append("extras", form.extras.join(", ") || "None");
    fd.append("date", form.bookingDate);
    fd.append("time", form.bookingTime);
    fd.append("notes", form.notes);
    fd.append("estimated_price", typeof totalPrice === "string" ? totalPrice : `£${totalPrice}`);
    fd.append("consent", "yes");
    setSending(true);
    const r = await sendFormData(fd);
    setSending(false);
    if (r.ok) setSent(true);
    else setErr(r.error || "Something went wrong.");
  };

  if (sent) {
    return (
      <div className="min-h-screen bg-slate-100 py-16 px-6">
        <div className="max-w-xl mx-auto bg-white p-10 rounded-xl shadow-lg text-center text-slate-900">
          <h1 className="text-2xl font-bold">Request received</h1>
          <p className="text-slate-700 mt-3">
            Thank you. We will check availability and confirm the final price with you shortly by phone, WhatsApp or email. This is not a confirmed booking yet.
          </p>
          <Link href="/" className="inline-block mt-6 bg-slate-900 text-white px-6 py-3 rounded-md font-semibold hover:bg-slate-700">Back to Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 py-16 px-6">
      <div className="max-w-4xl mx-auto bg-white p-6 sm:p-10 rounded-xl shadow-lg text-slate-900">
        <h1 className="text-3xl font-bold text-slate-900 text-center">
          Instant Price Estimate
        </h1>

        <p className="text-center text-slate-600 mt-2">
          Choose your service and property details to see an estimate. Then send us the request and we will confirm the final price and availability.
        </p>

        <div className="mt-10 grid md:grid-cols-2 gap-8">
          {/* LEFT SIDE */}
          <div>
            <label className="font-semibold">Service Type</label>
            <select
              className={inputStyle}
              value={form.service}
              onChange={(e) =>
                setForm({ ...form, service: e.target.value as ServiceType })
              }
            >
              <option value="">Select Service</option>
              {Object.keys(serviceRates).map((service) =>
                service ? (
                  <option key={service} value={service}>
                    {service}
                  </option>
                ) : null
              )}
            </select>

            <label className="font-semibold mt-6 block">Property Type</label>
            <input
              className={inputStyle}
              placeholder="e.g. Flat, House, Studio"
              value={form.propertyType}
              onChange={(e) =>
                setForm({ ...form, propertyType: e.target.value })
              }
            />

            <label className="font-semibold mt-6 block">Property Condition</label>
            <select
              className={inputStyle}
              value={form.condition}
              onChange={(e) =>
                setForm({ ...form, condition: e.target.value as PropertyCondition })
              }
            >
              <option>Existing</option>
              <option>New Build</option>
              <option>Renovated</option>
            </select>

            <label className="font-semibold mt-6 block">Supplies</label>
            <select
              className={inputStyle}
              value={form.supplies}
              onChange={(e) =>
                setForm({ ...form, supplies: e.target.value as SuppliesOption })
              }
            >
              <option>Customer Provides</option>
              <option>We Provide</option>
            </select>

            <label className="font-semibold mt-6 block">Hours Needed</label>
            <input
              type="number"
              min={calculateMinimumHours()}
              className={inputStyle}
              value={form.hours}
              onChange={(e) =>
                setForm({ ...form, hours: Number(e.target.value) })
              }
            />

            <label className="font-semibold mt-6 block">Rooms</label>
            <input
              type="number"
              min={0}
              max={10}
              className={inputStyle}
              placeholder="e.g. 2"
              value={form.rooms}
              onChange={(e) =>
                setForm({ ...form, rooms: Number(e.target.value) })
              }
            />

            <label className="font-semibold mt-6 block">Bathrooms</label>
            <input
              type="number"
              min={0}
              max={5}
              className={inputStyle}
              placeholder="e.g. 1"
              value={form.bathrooms}
              onChange={(e) =>
                setForm({ ...form, bathrooms: Number(e.target.value) })
              }
            />

            <label className="font-semibold mt-6 block">Toilets</label>
            <input
              type="number"
              min={0}
              max={5}
              className={inputStyle}
              placeholder="e.g. 1"
              value={form.toilets}
              onChange={(e) =>
                setForm({ ...form, toilets: Number(e.target.value) })
              }
            />

            <label className="font-semibold mt-6 block">Drainage Cleaning</label>
            <label className="flex items-center gap-2 mt-2">
              <input
                type="checkbox"
                checked={form.drainage}
                onChange={(e) =>
                  setForm({ ...form, drainage: e.target.checked })
                }
              />
              Drainage Cleaning (+£20)
            </label>

            <label className="font-semibold mt-6 block">Extras</label>
            <div className="grid gap-3 mt-3">
              {extraOptions.map((extra) => (
                <label key={extra.name} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={form.extras.includes(extra.name)}
                    onChange={() => toggleExtra(extra.name)}
                  />
                  {extra.name} (+£{extra.price})
                </label>
              ))}
            </div>
          </div>

          {/* RIGHT SIDE */}
          <div>
            <label className="font-semibold">Full Name</label>
            <input
              className={inputStyle}
              placeholder="Enter your full name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />

            <label className="font-semibold mt-6 block">Phone Number</label>
            <input
              className={inputStyle}
              placeholder="e.g. 07712 345678"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />

            <label className="font-semibold mt-6 block">Email</label>
            <input
              className={inputStyle}
              placeholder="e.g. name@example.com"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />

            <label className="font-semibold mt-6 block">Address</label>
            <input
              className={inputStyle}
              placeholder="Enter your full address"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
            />

            <label className="font-semibold mt-6 block">Postcode</label>
            <input
              className={inputStyle}
              placeholder="e.g. SE13 5XX"
              value={form.postcode}
              onChange={(e) => setForm({ ...form, postcode: e.target.value })}
            />

            <label className="font-semibold mt-6 block">Booking Date</label>
            <input
              type="date"
              className={inputStyle}
              value={form.bookingDate}
              onChange={(e) =>
                setForm({ ...form, bookingDate: e.target.value })
              }
            />

            <label className="font-semibold mt-6 block">Booking Time</label>
            <input
              type="time"
              className={inputStyle}
              value={form.bookingTime}
              onChange={(e) =>
                setForm({ ...form, bookingTime: e.target.value })
              }
            />

            <label className="font-semibold mt-6 block">Notes</label>
            <textarea
              className={inputStyle}
              placeholder="Any special instructions?"
              rows={4}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
            ></textarea>
          </div>
        </div>

        {/* PRICE */}
        <div className="text-center mt-10">
          <h2 className="text-2xl font-bold">Estimated Price</h2>

          {typeof totalPrice === "string" ? (
            <p className="text-xl font-bold text-red-600 mt-3">
              {totalPrice}
            </p>
          ) : (
            <p className="text-4xl font-bold text-green-600 mt-3">
              £{totalPrice}
            </p>
          )}
        </div>

        {/* BUTTONS */}
        <div className="max-w-xl mx-auto mt-10">
          <label className="flex gap-3 text-sm text-slate-700 items-start">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-1" />
            <span>I agree that {SITE.brand} may use these details to reply to my request, as described in the <Link href="/privacy" className="underline">privacy policy</Link>.</span>
          </label>

          {err && <p className="text-red-600 text-sm mt-3">{err}</p>}

          <div className="mt-5 flex flex-col sm:flex-row gap-3 justify-center">
            <button
              type="button"
              onClick={sendRequest}
              disabled={sending}
              className="bg-slate-900 text-white px-6 py-3 rounded-md font-semibold hover:bg-slate-700 disabled:opacity-60"
            >
              {sending ? "Sending…" : "Send booking request"}
            </button>
            <a
              href={whatsappMessage()}
              className="text-center bg-green-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-green-700"
            >
              Send on WhatsApp
            </a>
          </div>
          <p className="text-xs text-slate-500 text-center mt-4">The estimate is a guide. We confirm the final price before any work starts.</p>
        </div>
      </div>
    </div>
  );
}
