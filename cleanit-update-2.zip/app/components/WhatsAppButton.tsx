import { whatsappLink } from "../lib/config";

export default function WhatsAppButton() {
  return (
    <a
      href={whatsappLink("Hi, I would like to book a clean.")}
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-40 bg-green-500 text-white rounded-full shadow-lg px-5 py-3 text-sm font-semibold hover:bg-green-600"
    >
      WhatsApp us
    </a>
  );
}
